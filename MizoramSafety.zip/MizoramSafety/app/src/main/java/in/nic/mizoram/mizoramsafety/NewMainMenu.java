package in.nic.mizoram.mizoramsafety;

public class NewMainMenu {
}
